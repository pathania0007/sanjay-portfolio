# Replit.md

## Overview

This is a full-stack web application built with a React frontend and Express.js backend. The application appears to be a personal portfolio website for an AWS Cloud Engineer named Sanjay Pathania, showcasing his skills, experience, and projects. The application uses modern web technologies including TypeScript, Tailwind CSS, and Radix UI components.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for development and production builds
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Component Library**: Radix UI components with custom styling (shadcn/ui)
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **Forms**: React Hook Form with Zod validation
- **Animations**: Framer Motion for smooth animations and transitions

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: PostgreSQL session store with connect-pg-simple
- **Development**: Hot reloading with Vite middleware integration

### Key Components

1. **Portfolio Sections**:
   - Hero section with typing effect
   - About section with personal information
   - Skills section with progress bars and certifications
   - Experience timeline
   - Projects showcase
   - Contact form

2. **UI Components**: Complete set of reusable components from Radix UI including:
   - Form controls (Input, Textarea, Button, Select)
   - Layout components (Card, Dialog, Sheet, Tabs)
   - Feedback components (Toast, Alert, Progress)
   - Navigation components (Dropdown, Popover, Tooltip)

3. **Database Schema**: Currently includes a basic user schema with username and password fields

## Data Flow

1. **Frontend**: React components fetch data using TanStack Query
2. **API Layer**: Express.js routes handle HTTP requests (prefixed with `/api`)
3. **Storage Layer**: Abstracted storage interface with both memory and database implementations
4. **Database**: PostgreSQL with Drizzle ORM for type-safe database operations

## External Dependencies

- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **@radix-ui/***: Comprehensive UI component library
- **@tanstack/react-query**: Server state management
- **framer-motion**: Animation library
- **drizzle-orm**: Type-safe ORM for PostgreSQL
- **react-hook-form**: Form handling with validation
- **zod**: Schema validation
- **tailwindcss**: Utility-first CSS framework

## Deployment Strategy

- **Development**: Vite dev server with Express.js backend
- **Production**: 
  - Frontend built with Vite and served as static files
  - Backend bundled with esbuild as ES modules
  - Database migrations managed with Drizzle Kit
  - Environment variables for database connection

**Docker Deployment (New):**
- Multi-stage Docker build for optimized production images
- Non-root user for security
- Health check endpoints for monitoring
- Nginx reverse proxy configuration
- Docker Compose setup for easy deployment
- Production-ready with SSL/TLS support

The application follows a monorepo structure with shared TypeScript types and schemas between frontend and backend. The development setup includes hot reloading, error overlays, and Replit-specific tooling for cloud development.

## Recent Changes

**2024-01-09: Docker Deployment Setup**
- ✅ Created comprehensive Docker configuration with multi-stage builds
- ✅ Added health check endpoints (`/health` and `/api/health`)
- ✅ Implemented Nginx reverse proxy with security headers and rate limiting
- ✅ Docker Compose setup for production deployment
- ✅ Security hardening with non-root user and proper file permissions
- ✅ Complete deployment documentation and troubleshooting guides