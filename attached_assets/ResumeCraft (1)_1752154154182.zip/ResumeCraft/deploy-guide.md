# Docker Deployment Guide

This guide provides step-by-step instructions for deploying Sanjay Pathania's portfolio website using Docker.

## Prerequisites

- Docker installed on your system
- Docker Compose (optional, for advanced setup)
- 2GB+ available disk space
- Port 5000 available (or configure different port)

## Method 1: Simple Docker Run

### Step 1: Build the Image
```bash
# Run the build script
./build-docker.sh

# Or build manually
docker build -t sanjay-portfolio:latest .
```

### Step 2: Run the Container
```bash
# Basic run
docker run -p 5000:5000 sanjay-portfolio:latest

# Run in background (detached)
docker run -d -p 5000:5000 --name portfolio sanjay-portfolio:latest

# Run with custom port
docker run -d -p 8080:5000 --name portfolio sanjay-portfolio:latest
```

### Step 3: Access the Website
Open your browser and navigate to:
- `http://localhost:5000` (default)
- `http://localhost:8080` (if using custom port)

## Method 2: Docker Compose (Recommended)

### Step 1: Start Services
```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Step 2: Access the Website
- Main application: `http://localhost:5000`
- With Nginx proxy: `http://localhost:80`

## Production Deployment

### Environment Variables
Create a `.env` file:
```env
NODE_ENV=production
PORT=5000
# Add database credentials if needed
DATABASE_URL=your_production_database_url
```

### With Environment File
```bash
docker run -d \
  --env-file .env \
  -p 5000:5000 \
  --name portfolio \
  sanjay-portfolio:latest
```

### With Nginx Reverse Proxy
The included `nginx.conf` provides:
- SSL termination
- Gzip compression
- Rate limiting
- Security headers
- Static file caching

```bash
# Start with nginx proxy
docker-compose up -d nginx portfolio-web
```

## Monitoring and Maintenance

### Health Checks
```bash
# Check container health
docker ps

# Check application health
curl http://localhost:5000/health

# View container logs
docker logs portfolio

# Execute commands in running container
docker exec -it portfolio /bin/sh
```

### Container Management
```bash
# Stop container
docker stop portfolio

# Start container
docker start portfolio

# Remove container
docker rm portfolio

# Remove image
docker rmi sanjay-portfolio:latest
```

## Troubleshooting

### Common Issues

1. **Port Already in Use**
   ```bash
   # Find process using port 5000
   lsof -i :5000
   
   # Use different port
   docker run -p 8080:5000 sanjay-portfolio:latest
   ```

2. **Container Won't Start**
   ```bash
   # Check logs
   docker logs portfolio
   
   # Check container status
   docker ps -a
   ```

3. **Build Failures**
   ```bash
   # Clear Docker cache
   docker builder prune
   
   # Rebuild without cache
   docker build --no-cache -t sanjay-portfolio:latest .
   ```

### Performance Optimization

1. **Memory Limits**
   ```bash
   docker run -m 512m -p 5000:5000 sanjay-portfolio:latest
   ```

2. **CPU Limits**
   ```bash
   docker run --cpus="1.0" -p 5000:5000 sanjay-portfolio:latest
   ```

## Cloud Deployment

### AWS ECS
```bash
# Tag for ECR
docker tag sanjay-portfolio:latest your-account.dkr.ecr.region.amazonaws.com/sanjay-portfolio:latest

# Push to ECR
docker push your-account.dkr.ecr.region.amazonaws.com/sanjay-portfolio:latest
```

### Google Cloud Run
```bash
# Tag for GCR
docker tag sanjay-portfolio:latest gcr.io/your-project/sanjay-portfolio:latest

# Push to GCR
docker push gcr.io/your-project/sanjay-portfolio:latest
```

### Azure Container Instances
```bash
# Tag for ACR
docker tag sanjay-portfolio:latest your-registry.azurecr.io/sanjay-portfolio:latest

# Push to ACR
docker push your-registry.azurecr.io/sanjay-portfolio:latest
```

## Security Considerations

1. **Non-root User**: Container runs as non-root user `nextjs`
2. **Health Checks**: Built-in health monitoring
3. **Security Headers**: Nginx adds security headers
4. **Rate Limiting**: API endpoints are rate-limited
5. **SSL/TLS**: Configure SSL certificates for HTTPS

## Backup and Recovery

### Backup Container
```bash
# Create container backup
docker commit portfolio sanjay-portfolio:backup-$(date +%Y%m%d)

# Export image
docker save sanjay-portfolio:latest | gzip > portfolio-backup.tar.gz
```

### Restore Container
```bash
# Load image
docker load < portfolio-backup.tar.gz

# Run restored container
docker run -d -p 5000:5000 sanjay-portfolio:latest
```

## Support

For issues or questions:
- Check container logs: `docker logs portfolio`
- Verify health endpoint: `curl http://localhost:5000/health`
- Review this guide and README.md
- Contact: sanjaypathania0@gmail.com