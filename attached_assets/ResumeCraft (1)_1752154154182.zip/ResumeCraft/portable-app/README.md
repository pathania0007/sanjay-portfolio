# Portable Portfolio Application

This is a self-contained portable version of Sanjay Pathania's AWS Cloud Engineer portfolio website.

## Quick Start

### Windows
1. Double-click `start-app.bat`
2. Wait for the application to start
3. Open your browser to `http://localhost:5000`

### Linux/Mac
1. Open terminal in this directory
2. Run: `./start-app.sh`
3. Wait for the application to start
4. Open your browser to `http://localhost:5000`

## Requirements

- Node.js 18+ (will be downloaded if not available)
- 2GB+ free disk space
- Port 5000 available

## Features

- Complete portfolio website with animations
- Contact form with validation
- Responsive design
- Professional AWS-themed styling
- No external dependencies required

## Troubleshooting

If the application doesn't start:
1. Ensure port 5000 is available
2. Check that you have write permissions in this directory
3. Try running from command line to see error messages

## Contact

Sanjay Pathania
Email: sanjaypathania0@gmail.com
Phone: +91 9906298387
Location: HSR Sector 1, Bengaluru, India
