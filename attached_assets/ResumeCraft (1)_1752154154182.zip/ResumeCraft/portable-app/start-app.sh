#!/bin/bash

# Portable Portfolio Application Launcher
echo "Starting Sanjay Pathania Portfolio Application..."

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
APP_DIR="$SCRIPT_DIR/app"

# Check if Node.js is available
if ! command -v node &> /dev/null; then
    echo "Node.js not found. Using portable Node.js..."
    export PATH="$SCRIPT_DIR/node/bin:$PATH"
fi

# Change to app directory
cd "$APP_DIR"

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

# Build if needed
if [ ! -d "client/dist" ] || [ ! -d "dist" ]; then
    echo "Building application..."
    npm run build
fi

# Start the application
echo "Starting server on http://localhost:5000"
echo "Press Ctrl+C to stop the application"
NODE_ENV=production npm start
