#!/bin/bash

# Build script for Docker deployment
echo "Building Sanjay Pathania Portfolio Docker Image..."

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "Docker is not installed. Please install Docker first."
    exit 1
fi

# Build the Docker image
echo "Building Docker image..."
docker build -t sanjay-portfolio:latest .

# Check if build was successful
if [ $? -eq 0 ]; then
    echo "✅ Docker image built successfully!"
    echo "Image name: sanjay-portfolio:latest"
    echo ""
    echo "To run the container:"
    echo "  docker run -p 5000:5000 sanjay-portfolio:latest"
    echo ""
    echo "To run with Docker Compose:"
    echo "  docker-compose up -d"
    echo ""
    echo "To check container status:"
    echo "  docker ps"
else
    echo "❌ Docker build failed!"
    exit 1
fi