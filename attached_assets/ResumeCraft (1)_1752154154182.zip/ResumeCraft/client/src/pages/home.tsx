import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import AboutSection from "@/components/about-section";
import SkillsSection from "@/components/skills-section";
import ExperienceSection from "@/components/experience-section";
import ProjectsSection from "@/components/projects-section";
import ContactSection from "@/components/contact-section";
import Footer from "@/components/footer";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function Home() {
  const handleDownloadResume = () => {
    // Create a mock PDF blob for demonstration
    const element = document.createElement('a');
    element.href = 'data:application/pdf;base64,JVBERi0xLjQKJdPr6eEKMSAwIG9iago8PAovVGl0bGUgKFNhbmpheSBQYXRoYW5pYSAtIEFXUyBDbG91ZCBFbmdpbmVlciBSZXN1bWUpCi9DcmVhdG9yIChTYW5qYXkgUGF0aGFuaWEpCi9BdXRob3IgKFNhbmpheSBQYXRoYW5pYSkKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL1R5cGUgL0NhdGFsb2cKL1BhZ2VzIDMgMCBSCj4+CmVuZG9iagozIDAgb2JqCjw8Ci9UeXBlIC9QYWdlcwovQ291bnQgMQovS2lkcyBbNSAwIFJdCj4+CmVuZG9iago0IDAgb2JqCjw8Ci9UeXBlIC9Gb250Ci9TdWJ0eXBlIC9UeXBlMQovQmFzZUZvbnQgL0hlbHZldGljYQo+PgplbmRvYmoKNSAwIG9iago8PAovVHlwZSAvUGFnZQovUGFyZW50IDMgMCBSCi9NZWRpYUJveFswIDAgNjEyIDc5Ml0KL0NvbnRlbnRzIDYgMCBSCi9SZXNvdXJjZXMgPDwKL0ZvbnQgPDwKL0YxIDQgMCBSCj4+Cj4+Cj4+CmVuZG9iago2IDAgb2JqCjw8Ci9MZW5ndGggMTUwCj4+CnN0cmVhbQpCVApxCi9GMSAxMiBUZgoxIDAgMCAxIDEwMCA3NTAgVG0KKFNhbmpheSBQYXRoYW5pYSAtIEFXUyBDbG91ZCBFbmdpbmVlcikgVGoKRVQKUQplbmRzdHJlYW0KZW5kb2JqCnhyZWYKMCA3CjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDAwOSAwMDAwMCBuIAowMDAwMDAwMTI0IDAwMDAwIG4gCjAwMDAwMDAxNzEgMDAwMDAgbiAKMDAwMDAwMDIyOCAwMDAwMCBuIAowMDAwMDAwMjk1IDAwMDAwIG4gCjAwMDAwMDA0MjQgMDAwMDAgbiAKdHJhaWxlcgo8PAovU2l6ZSA3Ci9Sb290IDIgMCBSCi9JbmZvIDEgMCBSCj4+CnN0YXJ0eHJlZgo2MjQKJSVFT0Y=';
    element.download = 'Sanjay_Pathania_Resume.pdf';
    element.click();
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Floating Resume Download Button */}
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 2, duration: 0.5 }}
      >
        <Button
          onClick={handleDownloadResume}
          className="bg-[hsl(36,100%,50%)] hover:bg-[hsl(36,100%,45%)] text-white p-4 rounded-full shadow-lg transition-all duration-300 hover:scale-110"
          size="icon"
        >
          <Download className="h-6 w-6" />
        </Button>
      </motion.div>

      <HeroSection />
      <AboutSection />
      <SkillsSection />
      <ExperienceSection />
      <ProjectsSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
