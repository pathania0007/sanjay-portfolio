import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useTypingEffect } from "@/hooks/use-typing-effect";

const titles = [
  "AWS Cloud Engineer",
  "Infrastructure Architect", 
  "DevOps Specialist",
  "Cloud Consultant"
];

export default function HeroSection() {
  const displayText = useTypingEffect(titles, 150, 2000);

  const handleContactClick = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleProjectsClick = () => {
    const element = document.querySelector("#projects");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden aws-gradient">
      {/* Animated Background Particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(8)].map((_, i) => (
          <motion.div
            key={i}
            className="particle absolute bg-[hsl(36,100%,50%)] opacity-60 rounded-full"
            style={{
              width: `${Math.random() * 8 + 4}px`,
              height: `${Math.random() * 8 + 4}px`,
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, -20, 0],
              opacity: [0.3, 0.8, 0.3],
            }}
            transition={{
              duration: 4 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="text-center text-white z-10 max-w-4xl mx-auto px-4">
        <motion.h1
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold mb-6"
        >
          Hi, I'm{" "}
          <span className="text-[hsl(36,100%,50%)]">Sanjay</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-2xl md:text-4xl font-mono mb-8 h-16 flex items-center justify-center"
        >
          <span className="typing-cursor">{displayText}</span>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="text-xl md:text-2xl mb-10 text-gray-300 max-w-2xl mx-auto"
        >
          Results-driven AWS Cloud Engineer with 5+ years of experience in
          designing, implementing, and managing scalable cloud infrastructure
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.9 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Button
            onClick={handleContactClick}
            className="bg-[hsl(36,100%,50%)] text-white px-8 py-3 rounded-lg hover:bg-[hsl(36,100%,45%)] transition-all duration-300 hover:scale-105 font-semibold"
          >
            Get In Touch
          </Button>
          <Button
            onClick={handleProjectsClick}
            variant="outline"
            className="border-2 border-[hsl(36,100%,50%)] text-[hsl(36,100%,50%)] px-8 py-3 rounded-lg hover:bg-[hsl(36,100%,50%)] hover:text-white transition-all duration-300 hover:scale-105 font-semibold"
          >
            View Projects
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
