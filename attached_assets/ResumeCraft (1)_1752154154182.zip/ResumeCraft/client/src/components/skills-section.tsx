import { motion } from "framer-motion";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useEffect, useState } from "react";
import { Award, CheckCircle } from "lucide-react";

const awsSkills = [
  { name: "EC2 & Auto Scaling", level: 95 },
  { name: "S3 & Storage Solutions", level: 90 },
  { name: "VPC & Networking", level: 88 },
  { name: "Lambda & Serverless", level: 85 },
  { name: "CloudFormation & IaC", level: 82 },
];

const technicalSkills = [
  { name: "Load Balancing (ALB/NLB)", level: 90 },
  { name: "Transit Gateway & VPN", level: 85 },
  { name: "Route 53 & DNS", level: 80 },
  { name: "C++ Programming", level: 75 },
  { name: "HTML & CSS", level: 70 },
];

const certifications = [
  {
    name: "AWS Solution Architect",
    level: "Associate Level",
    status: "Certified",
    icon: "🏆",
    color: "bg-[hsl(36,100%,50%)]",
  },
  {
    name: "AWS System Administrator",
    level: "Professional Level", 
    status: "Certified",
    icon: "⚙️",
    color: "bg-[hsl(207,90%,54%)]",
  },
];

export default function SkillsSection() {
  const [animatedSkills, setAnimatedSkills] = useState<{ [key: string]: number }>({});

  useEffect(() => {
    const timer = setTimeout(() => {
      const allSkills = [...awsSkills, ...technicalSkills];
      const skillsObject = allSkills.reduce((acc, skill) => {
        acc[skill.name] = skill.level;
        return acc;
      }, {} as { [key: string]: number });
      setAnimatedSkills(skillsObject);
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[hsl(210,29%,16%)] mb-4">
            Skills & Expertise
          </h2>
          <div className="w-20 h-1 bg-[hsl(36,100%,50%)] mx-auto"></div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* AWS Services */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-bold text-[hsl(210,29%,16%)] mb-8 flex items-center">
              <svg viewBox="0 0 24 24" className="h-8 w-8 text-[hsl(36,100%,50%)] mr-3" fill="currentColor">
                <path d="M18.75 11.35a4.32 4.32 0 00-.79-.18 4.88 4.88 0 00-2.77.46 4.22 4.22 0 00-1.31 1.06 4.83 4.83 0 00-1.67-.76 4.27 4.27 0 00-1.7-.19 4.55 4.55 0 00-1.51.42 4.55 4.55 0 00-1.51-.42 4.27 4.27 0 00-1.7.19 4.83 4.83 0 00-1.67.76 4.22 4.22 0 00-1.31-1.06 4.88 4.88 0 00-2.77-.46 4.32 4.32 0 00-.79.18 1.75 1.75 0 00-1.25 1.68v4.95A1.75 1.75 0 002.5 19h19a1.75 1.75 0 001.75-1.75v-4.95a1.75 1.75 0 00-1.25-1.68zM12 17.5a2.5 2.5 0 01-2.5-2.5 2.5 2.5 0 012.5-2.5 2.5 2.5 0 012.5 2.5 2.5 2.5 0 01-2.5 2.5z"/>
              </svg>
              AWS Services
            </h3>
            <div className="space-y-6">
              {awsSkills.map((skill, index) => (
                <motion.div
                  key={skill.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="skill-item"
                >
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-semibold text-[hsl(210,29%,16%)]">
                      {skill.name}
                    </span>
                    <Badge variant="secondary" className="bg-[hsl(36,100%,50%)] text-white">
                      {skill.level}%
                    </Badge>
                  </div>
                  <Progress 
                    value={animatedSkills[skill.name] || 0} 
                    className="h-3"
                  />
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Technical Skills */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-bold text-[hsl(210,29%,16%)] mb-8 flex items-center">
              <svg viewBox="0 0 24 24" className="h-8 w-8 text-[hsl(36,100%,50%)] mr-3" fill="currentColor">
                <path d="M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0L19.2 12l-4.6-4.6L16 6l6 6-6 6-1.4-1.4z"/>
              </svg>
              Technical Skills
            </h3>
            <div className="space-y-6">
              {technicalSkills.map((skill, index) => (
                <motion.div
                  key={skill.name}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="skill-item"
                >
                  <div className="flex justify-between items-center mb-2">
                    <span className="font-semibold text-[hsl(210,29%,16%)]">
                      {skill.name}
                    </span>
                    <Badge variant="secondary" className="bg-[hsl(36,100%,50%)] text-white">
                      {skill.level}%
                    </Badge>
                  </div>
                  <Progress 
                    value={animatedSkills[skill.name] || 0} 
                    className="h-3"
                  />
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Certifications */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-16"
        >
          <h3 className="text-2xl font-bold text-[hsl(210,29%,16%)] mb-8 text-center flex items-center justify-center">
            <Award className="h-8 w-8 text-[hsl(36,100%,50%)] mr-3" />
            Certifications
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {certifications.map((cert, index) => (
              <motion.div
                key={cert.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                viewport={{ once: true }}
              >
                <Card className="bg-white hover:shadow-xl transition-all duration-300 hover:scale-105">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <div className={`w-16 h-16 ${cert.color} rounded-full flex items-center justify-center text-white text-2xl mr-4`}>
                        {cert.icon}
                      </div>
                      <div>
                        <h4 className="font-bold text-[hsl(210,29%,16%)]">
                          {cert.name}
                        </h4>
                        <p className="text-gray-600">{cert.level}</p>
                      </div>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full w-full"></div>
                    </div>
                    <div className="flex items-center mt-2">
                      <CheckCircle className="h-4 w-4 text-green-600 mr-2" />
                      <p className="text-sm text-green-600 font-semibold">
                        {cert.status}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
