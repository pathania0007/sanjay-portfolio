import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, Phone, MapPin, Globe, GraduationCap, Cloud } from "lucide-react";

export default function AboutSection() {
  const contactInfo = [
    {
      icon: Mail,
      title: "Email",
      value: "sanjaypathania0@gmail.com",
      href: "mailto:sanjaypathania0@gmail.com",
    },
    {
      icon: Phone,
      title: "Phone",
      value: "+91 9906298387",
      href: "tel:+919906298387",
    },
    {
      icon: MapPin,
      title: "Location",
      value: "HSR Sector 1, Bengaluru",
    },
    {
      icon: Globe,
      title: "Website",
      value: "www.sanjaypathania.in",
      href: "https://www.sanjaypathania.in",
    },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[hsl(210,29%,16%)] mb-4">
            About Me
          </h2>
          <div className="w-20 h-1 bg-[hsl(36,100%,50%)] mx-auto"></div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="w-80 h-80 mx-auto rounded-full bg-gradient-to-br from-[hsl(207,90%,54%)] to-[hsl(210,29%,16%)] flex items-center justify-center text-white text-6xl">
              <Cloud className="h-32 w-32" />
            </div>
            <motion.div
              initial={{ scale: 0 }}
              whileInView={{ scale: 1 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              viewport={{ once: true }}
              className="absolute -bottom-4 -right-4 w-20 h-20 bg-[hsl(36,100%,50%)] rounded-full flex items-center justify-center text-white text-2xl"
            >
              <svg viewBox="0 0 24 24" className="h-10 w-10" fill="currentColor">
                <path d="M18.75 11.35a4.32 4.32 0 00-.79-.18 4.88 4.88 0 00-2.77.46 4.22 4.22 0 00-1.31 1.06 4.83 4.83 0 00-1.67-.76 4.27 4.27 0 00-1.7-.19 4.55 4.55 0 00-1.51.42 4.55 4.55 0 00-1.51-.42 4.27 4.27 0 00-1.7.19 4.83 4.83 0 00-1.67.76 4.22 4.22 0 00-1.31-1.06 4.88 4.88 0 00-2.77-.46 4.32 4.32 0 00-.79.18 1.75 1.75 0 00-1.25 1.68v4.95A1.75 1.75 0 002.5 19h19a1.75 1.75 0 001.75-1.75v-4.95a1.75 1.75 0 00-1.25-1.68zM12 17.5a2.5 2.5 0 01-2.5-2.5 2.5 2.5 0 012.5-2.5 2.5 2.5 0 012.5 2.5 2.5 2.5 0 01-2.5 2.5z"/>
              </svg>
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-bold text-[hsl(210,29%,16%)] mb-6">
              AWS Cloud Engineer
            </h3>
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              I'm a passionate AWS Cloud Engineer with over 5 years of experience
              in designing, implementing, and managing cloud-based infrastructure
              and services. I specialize in building scalable, secure, and
              high-availability architectures using core AWS services including
              EC2, S3, RDS, VPC, IAM, CloudFormation, and Lambda.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {contactInfo.map((info, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="bg-[hsl(210,40%,96%)] hover:shadow-lg transition-shadow duration-300">
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <info.icon className="h-5 w-5 text-[hsl(36,100%,50%)] mr-3" />
                        <div>
                          <h4 className="font-semibold text-[hsl(210,29%,16%)] mb-1">
                            {info.title}
                          </h4>
                          {info.href ? (
                            <a
                              href={info.href}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-gray-700 hover:text-[hsl(36,100%,50%)] transition-colors duration-300"
                            >
                              {info.value}
                            </a>
                          ) : (
                            <p className="text-gray-700">{info.value}</p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <Card className="aws-gradient text-white">
                <CardContent className="p-6">
                  <div className="flex items-center mb-2">
                    <GraduationCap className="h-5 w-5 text-[hsl(36,100%,50%)] mr-3" />
                    <h4 className="font-semibold">Education</h4>
                  </div>
                  <p className="mb-1">B.Tech - Electronics and Communication</p>
                  <p className="text-sm text-gray-300">
                    Sri Sai College of Engineering and Technology (Punjab Technical University)
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
