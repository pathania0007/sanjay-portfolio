import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Network, HardDrive, Route } from "lucide-react";

const projects = [
  {
    title: "VPN Connection Setup",
    description: "Established secure connection between on-premises infrastructure and AWS cloud through VPN peering, ensuring encrypted data transmission.",
    icon: Network,
    iconColor: "bg-[hsl(36,100%,50%)]",
    technologies: ["VPN", "VPC", "Security"],
  },
  {
    title: "S3 Lifecycle Management",
    description: "Implemented automated S3 object lifecycle policies to optimize storage costs and manage data retention across different storage classes.",
    icon: HardDrive,
    iconColor: "bg-[hsl(207,90%,54%)]",
    technologies: ["S3", "Lifecycle", "Cost Optimization"],
  },
  {
    title: "Transit Gateway Setup",
    description: "Configured AWS Transit Gateway to enable seamless communication between private resources across multiple VPCs in a hub-and-spoke architecture.",
    icon: Route,
    iconColor: "bg-green-500",
    technologies: ["Transit Gateway", "VPC", "Networking"],
  },
];

export default function ProjectsSection() {
  return (
    <section id="projects" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[hsl(210,29%,16%)] mb-4">
            Projects
          </h2>
          <div className="w-20 h-1 bg-[hsl(36,100%,50%)] mx-auto"></div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="project-card bg-white hover:shadow-xl transition-all duration-300 hover:scale-105 h-full">
                <CardContent className="p-6 flex flex-col h-full">
                  <motion.div
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className={`w-16 h-16 ${project.iconColor} rounded-full flex items-center justify-center text-white text-2xl mb-4`}
                  >
                    <project.icon className="h-8 w-8" />
                  </motion.div>
                  
                  <h3 className="text-xl font-bold text-[hsl(210,29%,16%)] mb-3">
                    {project.title}
                  </h3>
                  
                  <p className="text-gray-700 mb-4 flex-grow">
                    {project.description}
                  </p>
                  
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.technologies.map((tech, techIndex) => (
                      <Badge
                        key={techIndex}
                        variant="secondary"
                        className="bg-[hsl(207,90%,54%)] text-white text-xs"
                      >
                        {tech}
                      </Badge>
                    ))}
                  </div>
                  
                  <Button
                    className="w-full bg-[hsl(36,100%,50%)] text-white hover:bg-[hsl(36,100%,45%)] transition-colors duration-300"
                    onClick={() => {
                      // Mock project details - in a real app, this would open a modal or navigate to a detailed view
                      alert(`${project.title} details will be implemented with actual project information`);
                    }}
                  >
                    View Details
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
