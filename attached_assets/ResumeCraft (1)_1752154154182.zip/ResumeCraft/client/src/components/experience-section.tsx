import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, MapPin } from "lucide-react";

const experiences = [
  {
    title: "AWS Cloud Engineer",
    company: "JARP",
    duration: "Feb 2024 - Nov 2024",
    location: "Noida",
    description: [
      "Designed and deployed scalable infrastructure using EC2, S3, RDS, Lambda, and VPC",
      "Managed disaster recovery and high availability across regions",
      "Implemented serverless solutions with Lambda and API Gateway",
      "Monitored infrastructure using CloudWatch and CloudTrail",
    ],
    side: "left",
  },
  {
    title: "SR Inside Sales Specialist",
    company: "Simplilearn",
    duration: "Nov 2022 - Feb 2024",
    location: "Bengaluru",
    description: [
      "Generated qualified leads through cold calls and email campaigns",
      "Assessed customer needs and recommended tailored cloud solutions",
      "Conducted virtual consultations and product demonstrations",
      "Managed full sales cycle from prospecting to closing deals",
    ],
    side: "right",
  },
  {
    title: "IT Engineer",
    company: "Burfee Solution",
    duration: "Jan 2018 - Aug 2022",
    location: "Jammu",
    description: [
      "Managed Microsoft Active Directory and networking equipment",
      "Implemented backup and disaster recovery in AWS Cloud",
      "Optimized S3 storage solutions with lifecycle policies",
      "Managed EBS snapshots and automated backup strategies",
    ],
    side: "left",
  },
];

export default function ExperienceSection() {
  return (
    <section id="experience" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-[hsl(210,29%,16%)] mb-4">
            Work Experience
          </h2>
          <div className="w-20 h-1 bg-[hsl(36,100%,50%)] mx-auto"></div>
        </motion.div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-[hsl(36,100%,50%)] hidden lg:block"></div>

          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="relative mb-16"
            >
              {/* Timeline dot */}
              <div className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 bg-[hsl(36,100%,50%)] rounded-full border-4 border-white shadow-lg z-10 hidden lg:block"></div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {exp.side === "left" ? (
                  <>
                    <div className="lg:text-right">
                      <Card className="bg-[hsl(210,40%,96%)] hover:shadow-xl transition-all duration-300 hover:scale-105">
                        <CardContent className="p-6">
                          <h3 className="text-xl font-bold text-[hsl(210,29%,16%)] mb-2">
                            {exp.title}
                          </h3>
                          <h4 className="text-[hsl(36,100%,50%)] font-semibold mb-2">
                            {exp.company}
                          </h4>
                          <div className="flex items-center text-gray-600 text-sm mb-4 lg:justify-end">
                            <Calendar className="h-4 w-4 mr-2" />
                            <span className="mr-4">{exp.duration}</span>
                            <MapPin className="h-4 w-4 mr-2" />
                            <span>{exp.location}</span>
                          </div>
                          <ul className="text-gray-700 space-y-2 text-sm">
                            {exp.description.map((item, i) => (
                              <li key={i}>• {item}</li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    </div>
                    <div className="lg:block hidden"></div>
                  </>
                ) : (
                  <>
                    <div className="lg:block hidden"></div>
                    <div>
                      <Card className="bg-[hsl(210,40%,96%)] hover:shadow-xl transition-all duration-300 hover:scale-105">
                        <CardContent className="p-6">
                          <h3 className="text-xl font-bold text-[hsl(210,29%,16%)] mb-2">
                            {exp.title}
                          </h3>
                          <h4 className="text-[hsl(36,100%,50%)] font-semibold mb-2">
                            {exp.company}
                          </h4>
                          <div className="flex items-center text-gray-600 text-sm mb-4">
                            <Calendar className="h-4 w-4 mr-2" />
                            <span className="mr-4">{exp.duration}</span>
                            <MapPin className="h-4 w-4 mr-2" />
                            <span>{exp.location}</span>
                          </div>
                          <ul className="text-gray-700 space-y-2 text-sm">
                            {exp.description.map((item, i) => (
                              <li key={i}>• {item}</li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    </div>
                  </>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
