#!/bin/bash

# Self-Extracting Portable Portfolio Application
# Created for Sanjay Pathania - AWS Cloud Engineer

TEMP_DIR=$(mktemp -d)
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

cleanup() {
    echo "Cleaning up temporary files..."
    rm -rf "$TEMP_DIR"
}

trap cleanup EXIT

echo "================================================"
echo "  Sanjay Pathania - AWS Cloud Engineer Portfolio"
echo "================================================"
echo ""
echo "🚀 Starting portable application..."
echo "📁 Extracting files to: $TEMP_DIR"

# Extract the embedded tar.gz file
ARCHIVE_LINE=$(awk '/^__ARCHIVE_BELOW__/ {print NR + 1; exit 0; }' "$0")
tail -n +$ARCHIVE_LINE "$0" | base64 -d | tar -xzf - -C "$TEMP_DIR"

cd "$TEMP_DIR"

# Check if Node.js is available
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found!"
    echo "Please install Node.js 18+ from https://nodejs.org/"
    echo "Or use the portable-app package which includes Node.js"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo "❌ Node.js version $NODE_VERSION is too old!"
    echo "Please install Node.js 18+ from https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js $(node -v) found"

# Install dependencies
echo "📦 Installing dependencies..."
npm install --silent > /dev/null 2>&1

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies!"
    echo "Please check your internet connection and try again."
    exit 1
fi

# Build the application
echo "🔨 Building application..."
npm run build --silent > /dev/null 2>&1

if [ $? -ne 0 ]; then
    echo "❌ Failed to build application!"
    exit 1
fi

echo "✅ Application built successfully!"
echo ""
echo "🌐 Starting server on http://localhost:5000"
echo "📱 Open your browser to view the portfolio"
echo "🛑 Press Ctrl+C to stop the application"
echo ""

# Start the application
NODE_ENV=production npm start

exit 0
__ARCHIVE_BELOW__
