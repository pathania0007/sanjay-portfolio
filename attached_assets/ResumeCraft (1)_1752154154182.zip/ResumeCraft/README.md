# Sanjay Pathania - AWS Cloud Engineer Portfolio

A modern, animated portfolio website showcasing AWS Cloud Engineer expertise built with React, Express.js, and TypeScript.

## Features

- **Animated Hero Section** with typing effects and floating particles
- **Responsive Design** optimized for all devices
- **Skills Showcase** with animated progress bars
- **Interactive Timeline** displaying work experience
- **Project Gallery** highlighting AWS implementations
- **Contact Form** with validation and modern UI
- **Dark/Light Theme Support** with smooth transitions
- **Professional AWS Theming** with custom color schemes

## Tech Stack

### Frontend
- React 18 with TypeScript
- Vite for build tooling
- Tailwind CSS for styling
- Framer Motion for animations
- Radix UI components
- React Hook Form with Zod validation
- TanStack Query for state management

### Backend
- Express.js with TypeScript
- PostgreSQL with Drizzle ORM
- Session management
- RESTful API design

## Quick Start

### Prerequisites
- Node.js 20 or later
- npm or yarn

### Development Setup

1. **Clone the repository**
```bash
git clone <repository-url>
cd portfolio-website
```

2. **Install dependencies**
```bash
npm install
```

3. **Start development server**
```bash
npm run dev
```

4. **Open in browser**
Visit `http://localhost:5000`

### Production Build

```bash
npm run build
npm start
```

## Docker Deployment

### Build Docker Image

```bash
docker build -t sanjay-portfolio .
```

### Run Container

```bash
docker run -p 5000:5000 sanjay-portfolio
```

### Docker Compose (Recommended)

```bash
docker-compose up -d
```

This will start:
- Portfolio application on port 5000
- Nginx reverse proxy on port 80/443 (optional)

## Project Structure

```
├── client/              # React frontend
│   ├── src/
│   │   ├── components/  # Reusable UI components
│   │   ├── hooks/       # Custom React hooks
│   │   ├── pages/       # Page components
│   │   └── lib/         # Utility functions
│   └── dist/           # Built frontend assets
├── server/             # Express.js backend
│   ├── index.ts        # Server entry point
│   ├── routes.ts       # API routes
│   └── vite.ts         # Vite integration
├── shared/             # Shared TypeScript types
└── Docker files        # Container configuration
```

## API Endpoints

- `GET /health` - Health check endpoint
- `GET /api/health` - API health check
- `POST /api/contact` - Contact form submission (planned)

## Environment Variables

```env
NODE_ENV=production
PORT=5000
DATABASE_URL=your_database_url
```

## Performance Features

- **Lazy Loading** - Components load on demand
- **Code Splitting** - Optimized bundle sizes
- **Image Optimization** - Responsive images with proper formats
- **Caching** - Static assets cached for optimal performance
- **Compression** - Gzip compression enabled
- **CDN Ready** - Static assets can be served from CDN

## Browser Support

- Chrome/Edge 88+
- Firefox 78+
- Safari 14+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature/new-feature`
3. Commit changes: `git commit -m 'Add new feature'`
4. Push to branch: `git push origin feature/new-feature`
5. Submit pull request

## License

MIT License - feel free to use this project for your own portfolio.

## Contact

**Sanjay Pathania**
- Email: sanjaypathania0@gmail.com
- Phone: +91 9906298387
- Location: HSR Sector 1, Bengaluru, India
- Website: www.sanjaypathania.in

## Deployment Notes

- Application runs on port 5000
- Health check available at `/health`
- Nginx configuration included for production
- Docker multi-stage build for optimized images
- Non-root user for security
- Process monitoring with health checks