# Single-File Deployment Package

I've created multiple deployment options for your portfolio website that require minimal setup:

## 📦 Available Packages

### 1. Single Executable File (Linux/Mac)
**File:** `portfolio-launcher.sh` (155KB)
**Requirements:** Node.js 18+, internet connection
**Usage:**
```bash
chmod +x portfolio-launcher.sh
./portfolio-launcher.sh
```

### 2. Portable Application Archive
**File:** `portable-app.tar.gz` (includes all files)
**Requirements:** Node.js 18+, internet connection
**Usage:**
```bash
tar -xzf portable-app.tar.gz
cd portable-app
./start-app.sh          # Linux/Mac
# or
start-app.bat           # Windows
```

### 3. Docker Image (Previous Option)
**Files:** `Dockerfile`, `docker-compose.yml`
**Requirements:** Docker installed
**Usage:**
```bash
docker-compose up -d
```

## 🚀 Recommended: Single Executable

The `portfolio-launcher.sh` file is a **self-contained executable** that:
- Contains your entire portfolio application
- Automatically extracts and sets up everything
- Installs dependencies automatically
- Builds and starts the application
- Cleans up temporary files when done

## 📋 What Happens When You Run It

1. **Extracts** the embedded application files to a temporary directory
2. **Checks** for Node.js 18+ (shows error if not found)
3. **Installs** all npm dependencies automatically
4. **Builds** the production application
5. **Starts** the server on http://localhost:5000
6. **Cleans up** temporary files when stopped

## 🌐 Portfolio Features Included

- Modern hero section with typing animations
- Interactive skills showcase with progress bars
- Professional work experience timeline
- AWS projects gallery
- Contact form with validation
- Responsive design for all devices
- Professional AWS-themed styling

## 📱 How to Share

**For End Users:**
1. Send them the `portfolio-launcher.sh` file
2. They just need to run: `./portfolio-launcher.sh`
3. It opens automatically in their browser

**For Windows Users:**
1. Send them the `portable-app.tar.gz` file
2. Extract and run `start-app.bat`

## 🔧 Technical Details

- **File Size:** ~155KB (compressed)
- **Memory Usage:** ~100MB when running
- **Startup Time:** 30-60 seconds (dependency installation)
- **Port:** 5000 (configurable)
- **Cleanup:** Automatic temporary file cleanup

## 🛡️ Security

- No external dependencies beyond Node.js
- Temporary files are cleaned up automatically
- Application runs in user space (no admin required)
- Self-contained with no system modifications

Your portfolio is now packaged as a single, portable file that anyone can run with just Node.js installed!