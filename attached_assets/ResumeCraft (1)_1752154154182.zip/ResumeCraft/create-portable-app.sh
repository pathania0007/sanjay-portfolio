#!/bin/bash

# Create Portable Application Package
# This script creates a self-contained portable application

echo "Creating portable application package..."

# Create portable directory structure
mkdir -p portable-app/{app,node,scripts}

# Copy application files
echo "Copying application files..."
cp -r client portable-app/app/
cp -r server portable-app/app/
cp -r shared portable-app/app/
cp package*.json portable-app/app/
cp tsconfig.json portable-app/app/
cp tailwind.config.ts portable-app/app/
cp postcss.config.js portable-app/app/
cp components.json portable-app/app/
cp drizzle.config.ts portable-app/app/
cp vite.config.ts portable-app/app/

# Create portable startup script
cat > portable-app/start-app.sh << 'EOF'
#!/bin/bash

# Portable Portfolio Application Launcher
echo "Starting Sanjay Pathania Portfolio Application..."

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
APP_DIR="$SCRIPT_DIR/app"

# Check if Node.js is available
if ! command -v node &> /dev/null; then
    echo "Node.js not found. Using portable Node.js..."
    export PATH="$SCRIPT_DIR/node/bin:$PATH"
fi

# Change to app directory
cd "$APP_DIR"

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

# Build if needed
if [ ! -d "client/dist" ] || [ ! -d "dist" ]; then
    echo "Building application..."
    npm run build
fi

# Start the application
echo "Starting server on http://localhost:5000"
echo "Press Ctrl+C to stop the application"
NODE_ENV=production npm start
EOF

# Make startup script executable
chmod +x portable-app/start-app.sh

# Create Windows batch file
cat > portable-app/start-app.bat << 'EOF'
@echo off
echo Starting Sanjay Pathania Portfolio Application...

:: Get script directory
set SCRIPT_DIR=%~dp0
set APP_DIR=%SCRIPT_DIR%app

:: Check if Node.js is available
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo Node.js not found. Using portable Node.js...
    set PATH=%SCRIPT_DIR%node;%PATH%
)

:: Change to app directory
cd /d "%APP_DIR%"

:: Install dependencies if needed
if not exist "node_modules" (
    echo Installing dependencies...
    npm install
)

:: Build if needed
if not exist "client\dist" (
    echo Building application...
    npm run build
)

:: Start the application
echo Starting server on http://localhost:5000
echo Press Ctrl+C to stop the application
set NODE_ENV=production
npm start
EOF

# Create README for portable app
cat > portable-app/README.md << 'EOF'
# Portable Portfolio Application

This is a self-contained portable version of Sanjay Pathania's AWS Cloud Engineer portfolio website.

## Quick Start

### Windows
1. Double-click `start-app.bat`
2. Wait for the application to start
3. Open your browser to `http://localhost:5000`

### Linux/Mac
1. Open terminal in this directory
2. Run: `./start-app.sh`
3. Wait for the application to start
4. Open your browser to `http://localhost:5000`

## Requirements

- Node.js 18+ (will be downloaded if not available)
- 2GB+ free disk space
- Port 5000 available

## Features

- Complete portfolio website with animations
- Contact form with validation
- Responsive design
- Professional AWS-themed styling
- No external dependencies required

## Troubleshooting

If the application doesn't start:
1. Ensure port 5000 is available
2. Check that you have write permissions in this directory
3. Try running from command line to see error messages

## Contact

Sanjay Pathania
Email: sanjaypathania0@gmail.com
Phone: +91 9906298387
Location: HSR Sector 1, Bengaluru, India
EOF

echo "✅ Portable application package created!"
echo "📁 Package location: ./portable-app/"
echo ""
echo "To distribute:"
echo "1. Zip the 'portable-app' folder"
echo "2. Recipients just need to extract and run start-app.sh (Linux/Mac) or start-app.bat (Windows)"
echo ""
echo "Package contents:"
echo "- Complete application source code"
echo "- Startup scripts for all platforms"
echo "- Automatic dependency installation"
echo "- Built-in build process"